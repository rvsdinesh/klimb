var express = require('express');
var mongoose = require('mongoose');
var multer = require('multer');
var path = require('path');
var userModel = require('./models/userModel');
var excelToJson = require('convert-excel-to-json');
var bodyParser = require('body-parser');
const fs = require('fs');


var storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './public/uploads');
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});
var uploads = multer({
    storage: storage
});
//connect to db  

mongoose.connect('mongodb+srv://dinesh:dinesh123@cluster1.3r8iz.mongodb.net/klimb?retryWrites=true&w=majority', {
        useNewUrlParser: true
    })
    .then(() => console.log('connected to db'))
    .catch((err) => console.log(err))
//init app  
var app = express();
//set the template engine  
app.set('view engine', 'ejs');
//fetch data from the request  
app.use(bodyParser.urlencoded({
    extended: false
}));
//static folder  
app.use(express.static(path.resolve(__dirname, 'public')));
//route for Home page
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});
// Upload excel file and import to mongodb
app.post('/uploadfile', uploads.single('filename'), (req, res) => {
    importExcelData2MongoDB(__dirname + '\\uploads\\' + req.file.filename);
});
// Import Excel File to MongoDB database
function importExcelData2MongoDB(filePath) {
    const excelData = excelToJson({
        sourceFile: filePath,
        header:{
            rows: 1
        },
        columnToKey: {
            A: 'NameOfTheCandidate',
            B: 'Email',
            C: 'MobileNo.',
            D: 'DateOfBirth',
            E: 'WorkExperience',
            F: 'ResumeTitle',
            G: 'CurrentLocation',
            H: 'PostalAddress',
            I: 'CurrentEmployer',
            J: 'CurrentDesignation'
        }
        
    });

    userModel.insertMany(excelData['Sheet1'], {ordered:false}, (err, res) => {
        if (err) {
            console.log(err);
        } else{
            Response.redirect('/');
        }
    });
    
    fs.unlinkSync(filePath);
    
}
//assign port  
var port = process.env.PORT || 5000;
app.listen(port, () => console.log('server run at port ' + port));