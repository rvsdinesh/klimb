var mongoose  =  require('mongoose');  
   
var excelSchema = new mongoose.Schema({  
    NameOfTheCandidate:{  
        type:String  
    },  
    Email:{  
        type:String  
    },    
    MobileNo:{  
        type:String  
    },
    DateOfBirth:{  
        type:String  
    },
    WorkExperience:{  
        type:String  
    },
    ResumeTitle:{  
        type:String  
    },
    CurrentLocation:{  
        type:String  
    },
    PostalAddress:{  
        type:String  
    },
    CurrentEmployer:{  
        type:String  
    },
    CurrentDesignation:{  
        type:String  
    }

});  
   
module.exports = mongoose.model('userModel',excelSchema);  
